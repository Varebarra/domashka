using System;
using System.Security.Cryptography;

namespace AuthorizationPractice
{
    public static class PasswordHasher
    {
        // Формат из AuthorizationPractice.sql:
        // iterations.saltBase64.hashBase64
        public static bool Verify(string password, string storedHash)
        {
            if (string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(storedHash))
                return false;

            try
            {
                string[] parts = storedHash.Split('.');
                if (parts.Length != 3)
                    return false;

                int iterations = int.Parse(parts[0]);
                byte[] salt = Convert.FromBase64String(parts[1]);
                byte[] expected = Convert.FromBase64String(parts[2]);

                using (var derive = new Rfc2898DeriveBytes(password, salt, iterations))
                {
                    byte[] actual = derive.GetBytes(expected.Length);
                    return FixedTimeEquals(actual, expected);
                }
            }
            catch
            {
                return false;
            }
        }

        private static bool FixedTimeEquals(byte[] a, byte[] b)
        {
            if (a == null || b == null || a.Length != b.Length)
                return false;

            int diff = 0;
            for (int i = 0; i < a.Length; i++)
                diff |= a[i] ^ b[i];

            return diff == 0;
        }
    }
}
